﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        If MsgBox("Are you sure you want to EXIT the program", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "EXIT") = MsgBoxResult.Yes Then
            Me.Close()
            LoginForm1.Dispose()
        Else
            Me.Show()
        End If

    End Sub

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem.Click
        Me.Close()
        Add_Child.Show()
        Add_Child.Button3.Visible = False
        Add_Child.Button4.Visible = False
    End Sub

    Private Sub SearchToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchToolStripMenuItem.Click
        Add_Child.Show()
        Add_Child.TextBox1.Focus()
        Add_Child.Button1.Visible = False
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        About.ShowDialog()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoutToolStripMenuItem.Click
        LoginForm1.Show()
        MENUToolStripMenuItem.Enabled = False
    End Sub
End Class
