﻿Public Class Add_Child
    Dim db As dao.Database
    Dim DBEngine As New dao.DBEngineClass
    Dim rsutable As dao.Recordset

    Private Sub Add_Child_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        db = DBEngine.OpenDatabase(My.Application.Info.DirectoryPath & "\child.mdb")
        rsutable = db.OpenRecordset("utable", 2)
        Button2.Text = "CANCEL"
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox2.Text = Nothing Or TextBox3.Text = Nothing Or TextBox4.Text = Nothing Or TextBox5.Text = Nothing Or TextBox6.Text = Nothing Or TextBox7.Text = Nothing Or TextBox8.Text = Nothing Or TextBox9.Text = Nothing Or TextBox10.Text = Nothing Or TextBox11.Text = Nothing Or TextBox12.Text = Nothing Or TextBox13.Text = Nothing Or Comadopt.Text = Nothing Then
            MsgBox("ALL DETAILS MUST BE FILLED", MsgBoxStyle.Critical)
            TextBox2.ForeColor = Color.Blue()
            TextBox2.Focus()
        Else
            With rsutable
                .AddNew()
                .Fields("surname").Value = TextBox2.Text
                .Fields("othernames").Value = TextBox3.Text
                .Fields("sex").Value = TextBox4.Text
                .Fields("age").Value = TextBox5.Text
                .Fields("nation").Value = TextBox6.Text
                .Fields("lga").Value = TextBox7.Text
                .Fields("state").Value = TextBox8.Text
                .Fields("disability").Value = TextBox9.Text
                .Fields("spdiet").Value = TextBox10.Text
                .Fields("pname").Value = TextBox11.Text
                .Fields("paddress").Value = TextBox12.Text
                .Fields("pno").Value = TextBox13.Text
                .Fields("adopt").Value = Comadopt.Text
                .Update()
                MsgBox("Record saved successfully!", MsgBoxStyle.Information)
                TextBox2.Text = ""
                TextBox3.Text = ""
                TextBox4.Text = ""
                TextBox5.Text = ""
                TextBox6.Text = ""
                TextBox7.Text = ""
                TextBox8.Text = ""
                TextBox9.Text = ""
                TextBox10.Text = ""
                TextBox11.Text = ""
                TextBox12.Text = ""
                TextBox13.Text = ""
                Comadopt.Text = ""
                Button2.Text = "CLOSE"
            End With
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If TextBox2.Text = Nothing Or TextBox3.Text = Nothing Or TextBox4.Text = Nothing Or TextBox5.Text = Nothing Or TextBox6.Text = Nothing Or TextBox7.Text = Nothing Or TextBox8.Text = Nothing Or TextBox9.Text = Nothing Or TextBox10.Text = Nothing Or TextBox11.Text = Nothing Or TextBox12.Text = Nothing Or TextBox13.Text = Nothing Or Comadopt.Text = Nothing Then
            MsgBox("ALL DETAILS MUST BE FILLED", MsgBoxStyle.Critical)
            TextBox2.ForeColor = Color.Blue()
            TextBox2.Focus()
        Else
            With rsutable
                .Edit()
                .Fields("surname").Value = TextBox2.Text
                .Fields("othernames").Value = TextBox3.Text
                .Fields("sex").Value = TextBox4.Text
                .Fields("age").Value = TextBox5.Text
                .Fields("nation").Value = TextBox6.Text
                .Fields("lga").Value = TextBox7.Text
                .Fields("state").Value = TextBox8.Text
                .Fields("disability").Value = TextBox9.Text
                .Fields("spdiet").Value = TextBox10.Text
                .Fields("pname").Value = TextBox11.Text
                .Fields("paddress").Value = TextBox12.Text
                .Fields("pno").Value = TextBox13.Text
                .Fields("adopt").Value = Comadopt.Text
                .Update()
                MsgBox("Record Updated successfully!", MsgBoxStyle.Information)
                TextBox2.Text = ""
                TextBox3.Text = ""
                TextBox4.Text = ""
                TextBox5.Text = ""
                TextBox6.Text = ""
                TextBox7.Text = ""
                TextBox8.Text = ""
                TextBox9.Text = ""
                TextBox10.Text = ""
                TextBox11.Text = ""
                TextBox12.Text = ""
                TextBox13.Text = ""
                Comadopt.Text = ""

            End With
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        With rsutable
            .FindFirst(("ID LIKE '") & TextBox1.Text & "'")
            If .NoMatch Then
                MsgBox("Record does not exist, put the correct ID number of the child", MsgBoxStyle.OkOnly)
            Else
                TextBox2.Text = .Fields("surname").Value
                TextBox3.Text = .Fields("othernames").Value
                TextBox4.Text = .Fields("sex").Value
                TextBox5.Text = .Fields("age").Value
                TextBox6.Text = .Fields("nation").Value
                TextBox7.Text = .Fields("lga").Value
                TextBox8.Text = .Fields("state").Value
                TextBox9.Text = .Fields("disability").Value
                TextBox10.Text = .Fields("spdiet").Value
                TextBox11.Text = .Fields("pname").Value
                TextBox12.Text = .Fields("paddress").Value
                TextBox13.Text = .Fields("pno").Value
                If .Fields("adopt").Value = Nothing Then
                    Comadopt.Text = Nothing
                Else
                    Comadopt.Text = .Fields("adopt").Value
                End If
            End If
        End With
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Comadopt.SelectedIndexChanged

    End Sub
End Class