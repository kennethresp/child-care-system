﻿Public Class LoginForm1
    Dim db As dao.Database
    Dim DBEngine As New dao.DBEngineClass
    Dim rslogin As dao.Recordset
    Dim c As Double

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        If uname.Text = Nothing Or pname.Text = Nothing Then
            MsgBox("FILL ALL THE DETAILS", MsgBoxStyle.Information)
            Me.Refresh()
            uname.ResetText()
        Else
            With rslogin
                .FindFirst(("password LIKE '") & pname.Text & "'")
                If .NoMatch Then
                    MsgBox("Username or Password not correct", MsgBoxStyle.Exclamation)
                    uname.Focus()
                Else
                    Timer1.Enabled = True
                    Label1.Visible = True
                    Label1.Text = "Please Wait ..."
                    uname.Clear()
                    pname.Clear()
                End If

            End With
        End If
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginForm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        OK.Enabled = False
        Label1.Visible = False
        db = DBEngine.OpenDatabase(My.Application.Info.DirectoryPath & "\child.mdb")
        rslogin = db.OpenRecordset("login", 2)
    End Sub

    Private Sub uname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles uname.TextChanged
        If uname.TextLength <> 0 Then
            OK.Enabled = True
        Else
            OK.Enabled = False
        End If
    End Sub

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgressBar1.Click
        
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        On Error Resume Next
        For Me.c = 1 To 100 Step 0.000001
            ProgressBar1.Value = c
        Next c
        Me.Hide()
        Timer1.Enabled = False
        If Form1.MENUToolStripMenuItem.Enabled = False Then
            Form1.MENUToolStripMenuItem.Enabled = True
        End If
        Label1.Visible = False
        About.ShowDialog()
        ProgressBar1.Value = False
    End Sub
End Class
